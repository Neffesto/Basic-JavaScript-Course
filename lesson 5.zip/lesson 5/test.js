'use strict';

const cartItem = {
    render(good) {
        return `<div class = "good">
            <div>Наименование: ${good.productName} </div>
            <div>Цена за штуку: ${good.productCost} </div>
            <div>Количество: ${good.productQuantity} </div>
            <div>Стоимость: ${good.productQuantity * good.productCost} </div>
        </div>`;
    }
}



const cart = {
    cartListBlock: null,
    cartButtom: null,
    cartItem,
    goods: [
        {
            productName: 'melon',
            productCost: 100,
            productQuantity: 2
        },
        {
            productName: 'orange',
            productCost: 15,
            productQuantity: 7
        },
    ],

    init() {
        this.cartListBlock = document.querySelector('.cart-list');
        this.cartButtom = document.querySelector('.cart-btn');
        this.cartButtom.addEventListener('click', this.clearCart.bind(this));

        this.render();
    },

    render() {
        if (this.goods.length) {
            this.goods.forEach(good => {
                this.cartListBlock.insertAdjacentHTML('beforeend', this.cartItem.render(good));
            });
            this.cartListBlock.insertAdjacentHTML('beforeend', `В корзине ${this.goods.length} позиций стоимостью ${this.getCartPrice()}`);
        } else {
            this.cartListBlock.textContent = 'Корзина пуста';
        }
    },

    getCartPrice() {
        return this.goods.reduce((accumulator, currentValue) => accumulator += currentValue.productCost * currentValue.productQuantity, 0);
    },

    clearCart() {
        this.goods = [];
        this.render;
    },
};

cart.init();